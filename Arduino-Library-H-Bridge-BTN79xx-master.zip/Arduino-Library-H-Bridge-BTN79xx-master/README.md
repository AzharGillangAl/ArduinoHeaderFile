# Arduino-Library-H-Bridge-BTN79xx
# This Arduino library can be used for all H-bridge that used or similar to BTN79xx series as IC.
# For example using IBT2, CH340, Dual BTS7970 or Dual BTN7970 H-Bridge Driver
